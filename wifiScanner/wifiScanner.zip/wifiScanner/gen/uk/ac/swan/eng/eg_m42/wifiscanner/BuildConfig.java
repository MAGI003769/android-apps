/** Automatically generated file. DO NOT MODIFY */
package uk.ac.swan.eng.eg_m42.wifiscanner;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}